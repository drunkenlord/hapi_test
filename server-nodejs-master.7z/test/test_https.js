const { exec } = require('child_process');
const fs   = require('fs');
const express  = require('express'); // Client/server library
var https = require('https')
const app      = express();
const server   = require("https").createServer(app);
const clc  = require('chalk');
const path = require("path");
const spawnSync = require('child_process').spawnSync;
var port = 8998;

const nodeexe = "'" + process.execPath + "' server.js";
const metadir = __dirname + '/../metadata';

const excludes =
	[
		"INTERMAGNET",
		"SuperMAG",
		"AutoplotExample1",
		"AutoplotExample2",
		"TestData3.0",
		"TestDataBad"
	];

function ds() {return (new Date()).toISOString() + " [server] ";};

var options = {};

var gen_ssl = (function(callback) {
  if(fs.existsSync(path.resolve(__dirname, './ssl/key.pem'))){
    fs.unlinkSync(path.resolve(__dirname, './ssl/key.pem'));
  }
  if(fs.existsSync(path.resolve(__dirname, './ssl/cert.pem'))){
    fs.unlinkSync(path.resolve(__dirname, './ssl/cert.pem'));
  }

var yourscript = exec('sh ./ssl/gen.sh',
        (error, stdout, stderr) => {
            if (error !== null) {
                console.log(`exec error: ${error}`);
            }

callback();
        });
      })


gen_ssl(certGenerated);

 function certGenerated() {
console.log("SSL Certificates are generated succesfully");
      }

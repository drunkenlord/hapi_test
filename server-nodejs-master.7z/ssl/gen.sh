#!/bin/bash
openssl genrsa -out key.pem
MSYS_NO_PATHCONV=1 openssl req -new -key key.pem -out csr.pem -subj "/C=US/ST=Ljubljana/L=Ljubljana/O=Security/OU=IT Department/CN=localhost"
openssl x509 -req -days 9999 -in csr.pem -signkey key.pem -out cert.pem
rm csr.pem
